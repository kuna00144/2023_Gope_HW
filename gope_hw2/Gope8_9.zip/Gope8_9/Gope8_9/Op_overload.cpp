#include <iostream>
#include <cmath>
#include <ctime>
#include <string>
#include "CMoney.h"
using namespace std;
const CMoney operator+(const CMoney& amount1, const CMoney& amount2);

int main()
{
    CMoney aMoney(14, 23), bMoney(7, 84), sumMoney;
    sumMoney = aMoney + bMoney;
    cout << "$" << sumMoney.GetDollar() << "." << sumMoney.GetCent() << endl;
}

const CMoney operator+(const CMoney& amount1, const CMoney& amount2)
{
    int allCents1 = amount1.GetCent() + amount1.GetDollar() * 100;
    int allCents2 = amount2.GetCent() + amount2.GetDollar() * 100;
    int sumAllCents = allCents1 + allCents2;
    int absAllCents = abs(sumAllCents);   // Money can be negative.
    int finalDollars = absAllCents / 100; // ������ ������
    int finalCents = absAllCents % 100;   // ������ ������
    if (sumAllCents < 0)
    {
        finalDollars = -finalDollars;
        finalCents = -finalCents;
    }

    return CMoney(finalDollars, finalCents);
}

bool operator==(const CMoney& amount1, const CMoney& amount2)
{
    return ((amount1.GetDollar() == amount2.GetDollar()) && (amount1.GetCent() == amount2.GetCent()));
}

const CMoney operator-(const CMoney& amount)
{
    return CMoney(-amount.GetDollar(), -amount.GetCent());
}